# Proyecto Electiva de Profundización I - Creación de APIs

## Integrantes:
[@juancdonado](https://github.com/juancdonado).
[@justynMeza](https://github.com/justynmeza).
[@Diego21605](https://github.com/Diego21605).
 
 # Sprint 1:
 
 ## Historia de Usuario EP-001 
 
 ![1](https://user-images.githubusercontent.com/53822139/189217756-837ef565-0d53-426c-a8de-15c4ed60a2e4.jpeg)

 ![2](https://user-images.githubusercontent.com/53822139/189217806-6241da24-acb8-4263-9a28-5241428112e8.jpeg)

 
  
  ## Historia Técnica EP-002 

 ![3](https://user-images.githubusercontent.com/53822139/189219692-602d209e-61e1-432e-945d-94f0c38f2f2b.jpeg)

